#include "perso.h"
#include "background.h"

#define GRAVITY 10
#define SPEED 5
#define MAX_SPEED 30





void main()
{
SDL_Init(SDL_INIT_VIDEO);
SDL_Surface *screen;
SDL_Surface *back;
back=IMG_Load("background.png");
screen=SDL_SetVideoMode (1000,600,32,SDL_HWSURFACE|SDL_DOUBLEBUF);

SDL_WM_SetCaption("personnage\t1",NULL);//titre de la fenetre

background b;
Input I,I2;
perso p ,p2;
SDL_Event event;
initialiser_perso (&p);
initialiser_perso2 (&p2);
initialiser_input (&I);
initialiser_input (&I2);
initialiser_backround (&b);
bool running=true;



SDL_EnableKeyRepeat(200,0);


while(running)
{


while(SDL_PollEvent(&event))
	{

		switch(event.type)
		{
		//
		case SDL_QUIT:
		// (*action)=0;
			running=false;
		break;
		case SDL_KEYDOWN:
			switch (event.key.keysym.sym)
			{
			/*	
			break; */
			case SDLK_LEFT :
				I.left=1;



      		break;
      		case SDLK_RIGHT :
				I.right=1;
				


      		break;
			case SDLK_SPACE :
				I.jump=1;
				if(p.rect.y==330)//
								p.speedY = -60;


			break; 
				case SDLK_p   : 
			p.speedX=MAX_SPEED;
			break; 
			/*;*/
				case SDLK_q :
				I2.left=1;



      		break;
      		case SDLK_d :
				I2.right=1;
				


      		break;
			case SDLK_z :
				I2.jump=1;
				if(p2.rect.y==330)//collision with ground
								p2.speedY = -60;
			 //collision with stairs -1 au lieu de -30
					//p.speedX=MAX_JUMP_SPEED;
			break; 
			 
			case SDLK_b   : 
			p2.speedX=MAX_SPEED;
			break; 
			}
		break;
		case SDL_KEYUP:
			switch (event.key.keysym.sym)
			{
			case SDLK_RIGHT:
				I.right=0;
			break;
			case SDLK_LEFT :
				I.left=0;
      		break;
			case SDLK_SPACE :
			I.jump=0; 

			break;
			case SDLK_p   : 
			p.speedX=5;
			break; 
			//
		//	break;
		
		
		case SDLK_d:
				I2.right=0;
			break;
			case SDLK_q :
				I2.left=0;
      		break;
			case SDLK_z :
			I2.jump=0; 

			break;
			case SDLK_b   : 
			p2.speedX=5;
			break; 
			//
		//	break;
			}
		break;
		
		}//
	}


 if (I.right==1)
{
	//p.speedX+=1;
	animation_right(&p);
	if (I.jump==0) mouvementright (&p);
	 else if (I.jump==1) jumpright (&p);
         scrolling_right (&b,&p,screen);
}
else if (I.left==1 )
{
	//p.speedX+=SPEED  ;
	animation_left(&p)     ;
	if (I.jump==0)  mouvementleft (&p);
	else if (I.jump==1) jumpleft (&p);
	scrolling_left (&b,&p,screen);

}

 if (I2.right==1)
{
	//p.speedX+=1;
	animation_right(&p2);
	if (I2.jump==0) mouvementright (&p2);
	 else if (I2.jump==1) jumpright (&p2);
         scrolling_right (&b,&p2,screen);
}
else if (I2.left==1 )
{
	//p.speedX+=SPEED  ;
	animation_left(&p2)     ;
	if (I2.jump==0)  mouvementleft (&p2);
	else if (I2.jump==1) jumpleft (&p2);
	scrolling_left (&b,&p2,screen);

}
/*else if (I.left==0 && I.down==0 && I.jump==0 && I.right==0 )
{
	animation_stable(&p);
}*/
p.speedY+=GRAVITY;
 p.rect.y += p.speedY;
 //p.rect_relative.y += p.speedY;
 if(p.rect.y >= 330)
 	 {
 		 p.rect.y= 330;
		// p.rect_relative.y= ground;
 		 p.speedY = 0;
         }
    //
	
	
	
	p2.speedY+=GRAVITY;
 p2.rect.y += p2.speedY;
 //p.rect_relative.y += p.speedY;
 if(p2.rect.y >= 330)
 	 {
 		 p2.rect.y= 330;
		// p.rect_relative.y= ground;
 		 p2.speedY = 0;
         }

    
	afficher_background(screen,&b);
	afficher_perso (&p,screen);
	//SDL_Flip(screen);
	SDL_Delay(16);
	
	
	
	
	
	afficher_perso (&p2,screen);
	SDL_Flip(screen);
	SDL_Delay(16);
}
TTF_Quit();




}
